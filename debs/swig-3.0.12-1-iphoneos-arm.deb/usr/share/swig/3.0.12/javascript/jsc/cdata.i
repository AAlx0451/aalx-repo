%include <typemaps/cdata.swg>
