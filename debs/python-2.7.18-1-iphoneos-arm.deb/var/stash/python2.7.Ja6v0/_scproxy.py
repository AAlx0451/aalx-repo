def _get_proxy_settings():
    return None

def _get_proxies():
    return {}

